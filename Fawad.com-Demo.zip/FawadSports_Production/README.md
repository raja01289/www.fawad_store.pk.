# Fawad.com Sports & Fashion Store — Demo

A complete beginner-friendly Node.js + Express + SQLite e-commerce demo inspired by modern Pakistani sports stores. It uses original Fawad.com branding and does not copy another store's branding/assets.

## Included
- Responsive storefront
- Football, Cricket, Jerseys, Shoes and Accessories categories
- Search and category filtering
- Shopping cart
- Cash-on-delivery checkout
- WhatsApp order handoff
- SQLite products and orders database
- Admin login
- Admin product add/delete
- Admin order status management
- Product image upload API
- Basic security middleware and validation
- Demo products are created automatically on first run

## Run on Windows
1. Install Node.js 20+ LTS.
2. Open Command Prompt in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Demo admin
Username: `admin`
Password: `admin123`

Change the password and session secret before any public deployment.

## Admin
Open `http://localhost:3000/admin.html`.

## Important
This is a demo/baseline, not a guarantee of zero bugs or production security. Before public launch, use HTTPS, strong unique secrets, backups, proper payment-gateway integration, and dependency updates. Never collect raw card numbers in this app.
